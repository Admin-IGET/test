﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Media;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;

namespace UvikPic
{
    public partial class topbar : Form
    {
        private string free;
        private string fullscreenfs;
        private string circle;
        private string square;
        private string windowswnd;
        Color taskButtonColor = Color.White;
        Color taskButtonHoverColor = Color.Blue;
        Color panelColor = Color.Black;
        bool isResizable;
        bool isMinimizable;
        bool isBorderless;
        Color textColor = Color.Black;
        Color startButtonColor;
        bool isMaximized = false;
        private bool isResizing = false;
        private Point resizeStartMouse;
        private Rectangle resizeStartBounds;
        Rectangle normalBounds;
        Timer WarnTmr;

        Point shown = new Point(0, 0);
        Point hidden = new Point(0, -30);
        [DllImport("user32.dll")]
        static extern IntPtr SetThreadDpiAwarenessContext(IntPtr dpiContext);

        static readonly IntPtr DPI_UNAWARE = new IntPtr(-1);
        static readonly IntPtr DPI_AWARE = new IntPtr(-2);
        static readonly IntPtr DPI_PER_MONITOR_AWARE_V2 = new IntPtr(-4);

        private bool cz;

        private string tooltiptext;

        private void topbar_Load(object sender, EventArgs e)
        {

            this.ActiveControl = label1;


            this.Width = Screen.PrimaryScreen.Bounds.Width;
            this.Location = shown;
            this.BackColor = Color.White;
            this.TopMost = true;
            this.BringToFront();
            this.Height = 30;
            if (Environment.OSVersion.Version.Major == 10)
            {
                button3.Visible = true;
            }
            else
            {
                button3.Visible = false;
            }
            
        }

        private void LoadSettings()
        {
            try
            {
                bool hasTaskButtonColor = false;
                bool hasTaskButtonHoverColor = false;

                taskButtonColor = ColorTranslator.FromHtml("#FF0000");
                taskButtonHoverColor = ColorTranslator.FromHtml("#0000FF");

                string settingsPath = @"C:\apps\settings.txt";

                if (File.Exists(settingsPath))
                {
                    string[] lines = File.ReadAllLines(settingsPath);
                    foreach (string line in lines)
                    {
                        string[] parts = line.Split('=');
                        if (parts.Length == 2)
                        {
                            string key = parts[0].Trim().ToLower();
                            string value = parts[1].Trim();

                            switch (key)
                            {
                                case "color":
                                    try
                                    {
                                        panelColor = ColorTranslator.FromHtml(value);

                                        int r3, g3, b3;
                                        if (panelColor.R > 85)
                                            r3 = panelColor.R - 170;
                                        else
                                            r3 = panelColor.R + 170;

                                        if (panelColor.G > 85)
                                            g3 = panelColor.G - 170;
                                        else
                                            g3 = panelColor.G + 170;

                                        if (panelColor.B > 85)
                                            b3 = panelColor.B - 170;
                                        else
                                            b3 = panelColor.B + 170;

                                        startButtonColor = Color.FromArgb(r3, g3, b3);
                                    }
                                    catch { }
                                    break;

                                case "taskbuttoncolor":
                                    try
                                    {
                                        taskButtonColor = ColorTranslator.FromHtml(value);
                                        hasTaskButtonColor = true;
                                    }
                                    catch { }
                                    break;

                                case "taskbuttonhovercolor":
                                    try
                                    {
                                        taskButtonHoverColor = ColorTranslator.FromHtml(value);
                                        hasTaskButtonHoverColor = true;
                                    }
                                    catch { }
                                    break;
                            }
                        }
                    }

                    List<string> linesToAdd = new List<string>();

                    if (!hasTaskButtonColor)
                    {
                        linesToAdd.Add("");
                        linesToAdd.Add("taskButtonColor=#FF0000");
                    }

                    if (!hasTaskButtonHoverColor)
                    {
                        linesToAdd.Add("");
                        linesToAdd.Add("taskButtonHoverColor=#0000FF");
                    }

                    if (linesToAdd.Count > 0)
                        File.AppendAllLines(settingsPath, linesToAdd.ToArray());
                }
                else
                {
                    List<string> defaultLines = new List<string>();
                    defaultLines.Add("taskButtonColor=#FF0000");
                    defaultLines.Add("taskButtonHoverColor=#0000FF");
                    File.WriteAllLines(settingsPath, defaultLines.ToArray());
                }
            }
            catch { }
            if (File.Exists("C:\\edit\\blacktext.txt"))
            {
                textColor = Color.Black;
            }
            else
            {
                textColor = Color.White;
            }
            AplajKalrs(this);
        }

        private void AplajKalrs(Control c)
        {
            foreach (Control jezevec in c.Controls)
            {
                if ((jezevec is Button))
                {
                    ((Button)jezevec).FlatStyle = FlatStyle.Standard;
                    jezevec.MouseEnter += (s, e) => {
                        ((Button)jezevec).FlatStyle = FlatStyle.Popup;
                    };
                    jezevec.MouseLeave += (s, e) => {
                        ((Button)jezevec).FlatStyle = FlatStyle.Standard;
                    };
                }

                if (jezevec.Name == "titlebar" || jezevec.Name == "borderright" || jezevec.Name == "borderleft" || jezevec.Name == "borderbottom" || jezevec.Name == "resize")
                {
                    jezevec.BackColor = panelColor;
                }
                if (jezevec.Name == "titletext")
                {
                    if (File.Exists("C:\\apps\\panel.ps1"))
                    {
                        jezevec.ForeColor = textColor;
                    }
                    else
                    {
                        jezevec.ForeColor = Color.White;
                    }
                }
                if (jezevec.Name == "CloseBtn")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if (jezevec.Name == "BigBtn")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if (jezevec.Name == "MiniBtn")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if (jezevec.Name == "CloseLbl")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if (jezevec.Name == "MiniLbl")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;

                }

                if (jezevec.Name == "BigLbl")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if (jezevec.Name == "MiniLbl")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if ((jezevec is Button))
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = panelColor;
                    jezevec.Click += (s, e) =>
                    {
                        if (jezevec.Name != "button5")
                        {

                        }
                    };
                    jezevec.MouseEnter += (s, e) =>
                    {
                        jezevec.BackColor = taskButtonHoverColor;
                    };
                    jezevec.MouseLeave += (s, e) =>
                    {
                        jezevec.BackColor = panelColor;
                    };
                }

                if (jezevec.HasChildren)
                {
                    AplajKalrs(jezevec);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            new ScreenCapture().Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Location = hidden;
            new CircleCapture().Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            new FreeCapture().Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private string GenerateSavePath()
        {
            string folder = @"C:\edit\personal";
            Directory.CreateDirectory(folder);

            Random rnd = new Random();
            string path;

            do
            {
                int num = rnd.Next(0, 1000);
                path = Path.Combine(folder, $"snimek{num}.png");
            }
            while (File.Exists(path));

            return path;
        }



        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Timer timer = new Timer();
            timer.Interval = 200;
            timer.Tick += (s, ev) =>
            {
                timer.Stop();
                try
                {
                    string savePath = GenerateSavePath();

                    Rectangle bounds = Screen.PrimaryScreen.Bounds;

                    using (Bitmap screenshot = new Bitmap(bounds.Width, bounds.Height))
                    {
                        using (Graphics g = Graphics.FromImage(screenshot))
                        {
                            g.CopyFromScreen(Point.Empty, Point.Empty, bounds.Size);
                        }

                        screenshot.Save(savePath, ImageFormat.Png);
                    }

                    preparetosave pts = new preparetosave(savePath);
                    pts.Show();

                    this.Hide();
                }
                catch (Exception ex)
                {
                    this.Show();
                    MessageBox.Show("Chyba: " + ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Environment.Exit(0);
                }
            };
            timer.Start();



        }

        private void button4_Click(object sender, EventArgs e)
        {
            new selectwindow().Show();
            this.Hide();
        }

        private void topbar_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        public topbar()
        {
            if (File.ReadAllText("C:\\apps\\UvikVersionInformation.uvikos").Contains("CZ"))
            {
                cz = true;
            }
            if (cz) { free = "Volný výběr"; } else { free = "Free select"; }
            if (cz) { circle = "Označit kruh"; } else { circle = "Select circle"; }
            if (cz) { square = "Označit čtverec"; } else { square = "Select rectangle"; }
            if (cz) { fullscreenfs = "Celá obrazovka"; } else { fullscreenfs = "Full screen"; }
            if (cz) { windowswnd = "Vybrat okno"; } else { windowswnd = "Select a window"; }
            if (cz) { tooltiptext = "Otevře program výstřižky"; } else { tooltiptext = "Opens the snipping tool"; }


            InitializeComponent();
            SetThreadDpiAwarenessContext(DPI_UNAWARE);
            button1.Dock = DockStyle.Left;
            button2.Dock = DockStyle.Left;
            button3.Dock = DockStyle.Right;
            button5.Dock = DockStyle.Right;
            this.AutoScaleMode = AutoScaleMode.None;
            toolTip1.SetToolTip(button3, tooltiptext);
            button1.Text = square;
            button2.Text = free;
            LoadSettings();
        }



        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Hide();

            if (Environment.OSVersion.Platform == PlatformID.Win32NT)
            {
                try
                {
                    if (Environment.OSVersion.Version.Major == 10 && Environment.OSVersion.Version.Build >= 10240)
                    {
                        Process.Start(new ProcessStartInfo("ms-screenclip:")
                        {
                            UseShellExecute = true
                        });
                    }
                    this.Close();
                }
                catch (Exception)
                {
                    this.Show();
                    button3.Visible = false;
                    Environment.Exit(0);
                }
            }
        }

    }
}
