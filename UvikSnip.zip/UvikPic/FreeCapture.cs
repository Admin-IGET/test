﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace UvikPic
{
    public partial class FreeCapture : Form
    {
        private Bitmap screenshot;
        private Bitmap displayScreenshot;
        private List<Point> points = new List<Point>();
        private bool drawing = false;

        private const int DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = -4;
        [DllImport("user32.dll")]
        static extern IntPtr SetThreadDpiAwarenessContext(IntPtr dpiContext);

        static readonly IntPtr DPI_UNAWARE = new IntPtr(-1);
        static readonly IntPtr DPI_AWARE = new IntPtr(-2);
        static readonly IntPtr DPI_PER_MONITOR_AWARE_V2 = new IntPtr(-4);

        public FreeCapture()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;
            this.TopMost = true;
            SetThreadDpiAwarenessContext(DPI_PER_MONITOR_AWARE_V2);
        }

        private void TakeScreenshots()
        {
            try
            {
                Rectangle bounds = Screen.PrimaryScreen.Bounds;

                bool wasVisible = this.Visible;
                this.Hide();
                Application.DoEvents();

                Bitmap captured = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format32bppArgb);

                using (Graphics g = Graphics.FromImage(captured))
                {
                    g.CopyFromScreen(bounds.Location, Point.Empty, bounds.Size, CopyPixelOperation.SourceCopy);
                }

                if (screenshot != null)
                {
                    screenshot.Dispose();
                    screenshot = null;
                }

                if (displayScreenshot != null)
                {
                    displayScreenshot.Dispose();
                    displayScreenshot = null;
                }

                screenshot = captured;

                displayScreenshot = new Bitmap(screenshot.Width, screenshot.Height, PixelFormat.Format32bppArgb);
                using (Graphics g = Graphics.FromImage(displayScreenshot))
                {
                    g.DrawImage(screenshot, 0, 0);
                    using (Brush b = new SolidBrush(Color.FromArgb(150, Color.Black)))
                    {
                        g.FillRectangle(b, 0, 0, displayScreenshot.Width, displayScreenshot.Height);
                    }
                }

                if (wasVisible)
                {
                    this.Show();
                    Application.DoEvents();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                if (screenshot != null)
                {
                    screenshot.Dispose();
                    screenshot = null;
                }

                if (displayScreenshot != null)
                {
                    displayScreenshot.Dispose();
                    displayScreenshot = null;
                }
            }
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            drawing = true;
            points.Clear();
            points.Add(e.Location);
            Invalidate();
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (drawing)
            {
                points.Add(e.Location);
                Invalidate();
            }
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            drawing = false;

            if (points.Count > 3 && screenshot != null)
                SavePolygonCapture();

            this.Close();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (displayScreenshot != null)
                e.Graphics.DrawImage(displayScreenshot, 0, 0);

            if (points.Count > 1)
            {
                using (Pen p = new Pen(Color.Red, 2))
                    e.Graphics.DrawLines(p, points.ToArray());
            }
        }

        private void SavePolygonCapture()
        {
            if (screenshot == null)
            {
                MessageBox.Show("Error");
                return;
            }

            string folder = @"C:\edit\personal";
            Directory.CreateDirectory(folder);

            Random rnd = new Random();
            string path;

            do
            {
                int num = rnd.Next(0, 1000);
                path = Path.Combine(folder, $"snimek{num}.png");
            }
            while (File.Exists(path));

            // Uzavřít polygon
            using (GraphicsPath gp = new GraphicsPath())
            {
                gp.AddPolygon(points.ToArray());

                // 1) Vytvořit bitmapu přesně velikosti celé obrazovky
                using (Bitmap mask = new Bitmap(screenshot.Width, screenshot.Height, PixelFormat.Format32bppArgb))
                {
                    using (Graphics g = Graphics.FromImage(mask))
                    {
                        g.SmoothingMode = SmoothingMode.AntiAlias;

                        // Vyplnit polygon screenshotem (používáme jasný screenshot)
                        using (Region region = new Region(gp))
                        {
                            g.SetClip(region, CombineMode.Replace);

                            g.DrawImage(
                                screenshot,
                                new Rectangle(0, 0, screenshot.Width, screenshot.Height),
                                new Rectangle(0, 0, screenshot.Width, screenshot.Height),
                                GraphicsUnit.Pixel
                            );
                        }
                    }

                    // 2) Oříznout bitmapu na nejmenší obdélník polygonu
                    Rectangle bounds = Rectangle.Round(gp.GetBounds());
                    if (bounds.Width <= 0 || bounds.Height <= 0)
                    {
                        MessageBox.Show("Neplatné rozměry výsledného obrázku.");
                        return;
                    }

                    using (Bitmap final = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format32bppArgb))
                    {
                        using (Graphics g = Graphics.FromImage(final))
                        {
                            g.DrawImage(
                                mask,
                                new Rectangle(0, 0, bounds.Width, bounds.Height),
                                bounds,
                                GraphicsUnit.Pixel
                            );
                        }

                        // Zapisovat přes FileStream — spolehlivější vůči GDI+ locking chybám
                        try
                        {
                            using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None))
                            {
                                final.Save(fs, ImageFormat.Png);
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Chyba při ukládání (GDI+): " + ex.Message);
                            return;
                        }
                    }
                }
            }
            var old = SetThreadDpiAwarenessContext(DPI_UNAWARE);
            preparetosave pts = new preparetosave(path);
            pts.Show();
            SetThreadDpiAwarenessContext(old);
        }

        private void FreeCapture_Load(object sender, EventArgs e)
        {
            TakeScreenshots();
        }

        private void FreeCapture_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Uvolnit bitmapy
            if (screenshot != null)
            {
                screenshot.Dispose();
                screenshot = null;
            }

            if (displayScreenshot != null)
            {
                displayScreenshot.Dispose();
                displayScreenshot = null;
            }

           // Environment.Exit(0);
        }
    }
}
