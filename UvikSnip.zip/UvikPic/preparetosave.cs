﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UvikPic
{
    public partial class preparetosave : Form
    {

        private string imagePath;
        private Image loadedImage;

        // NASTAVENÍ UvíkOS OKEN
        private void CodeSettings()
        {
            isResizable = true;
            isMinimizable = true;
            isBorderless = false;
        }

        // POD TÍMTO ŘÁDKEM ZAČÍNÁ KÓD UvíkOS OKEN

        Color taskButtonColor = Color.White;
        Color taskButtonHoverColor = Color.Blue;
        Color panelColor = Color.Black;
        bool isResizable;
        bool isMinimizable;
        bool isBorderless;
        Color textColor = Color.Black;
        Color startButtonColor;
        bool isMaximized = false;
        private bool isResizing = false;
        private Point resizeStartMouse;
        private Rectangle resizeStartBounds;
        Rectangle normalBounds;
        Timer WarnTmr;
        [DllImport("user32.dll")]
        private static extern bool SetProcessDpiAwarenessContext(int dpiFlag);

        private const int DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = 4;

        private void Form1_Load(object sender, EventArgs e)
        {
            CodeSettings();
            FormLoaded();
            //this.AutoScaleMode = AutoScaleMode.Dpi;
            titletext.Text = this.Text;
            this.ActiveControl = WarnLbl; // aby tlacitka nezustala oznacena
            if (File.Exists("C:\\apps\\panel.ps1"))
            {
                LoadSettings();
            }
            else
            {
                WarnLbl.Show();
                WarnLbl.BringToFront();
                AplajKalrs(this);

                WarnTmr.Start();
            }
            if (isResizable)
            {
                MakeResizable();
            }
            else
            {
                MakeUnresizable();
            }
            if (!isMinimizable)
            {
                MakeUnminimizable();
            }
            if (isBorderless)
            {
                borderleft.Visible = false;
                borderright.Visible = false;
                borderbottom.Visible = false;
                resize.Visible = false;
                titlebar.Visible = false;
            }
            borderleft.SendToBack();
            borderright.SendToBack();
            borderbottom.SendToBack();
            resize.BringToFront();
            titlebar.SendToBack();
            pictureBox1.SendToBack();
            label1.SendToBack();
            button1.SendToBack();
            button2.SendToBack();
            SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
        }
        private void MakeResizable()
        {
            borderleft.MouseDown += ResizePanel_MouseDown;
            borderleft.MouseMove += borderLeft_MouseMove;
            borderleft.MouseUp += borderLeft_MouseUp;

            borderright.MouseDown += ResizePanel_MouseDown;
            borderright.MouseMove += borderRight_MouseMove;
            borderright.MouseUp += borderLeft_MouseUp;

            borderbottom.MouseDown += ResizePanel_MouseDown;
            borderbottom.MouseMove += borderBottom_MouseMove;
            borderbottom.MouseUp += borderLeft_MouseUp;

            resize.MouseDown += ResizePanel_MouseDown;
            resize.MouseMove += resize_MouseMove;
            resize.MouseUp += borderLeft_MouseUp;

            borderleft.Cursor = Cursors.SizeWE;
            borderright.Cursor = Cursors.SizeWE;
            borderbottom.Cursor = Cursors.SizeNS;
            resize.Cursor = Cursors.SizeNWSE;
        }
        private void MakeUnresizable()
        {
            MiniBtn.Location = BigBtn.Location;
            BigBtn.Visible = false;
        }
        private void MakeUnminimizable()
        {
            MiniBtn.Visible = false;
        }
        private void LoadSettings()
        {
            try
            {
                bool hasTaskButtonColor = false;
                bool hasTaskButtonHoverColor = false;

                taskButtonColor = ColorTranslator.FromHtml("#FF0000");
                taskButtonHoverColor = ColorTranslator.FromHtml("#0000FF");

                string settingsPath = @"C:\apps\settings.txt";

                if (File.Exists(settingsPath))
                {
                    string[] lines = File.ReadAllLines(settingsPath);
                    foreach (string line in lines)
                    {
                        string[] parts = line.Split('=');
                        if (parts.Length == 2)
                        {
                            string key = parts[0].Trim().ToLower();
                            string value = parts[1].Trim();

                            switch (key)
                            {
                                case "color":
                                    try
                                    {
                                        panelColor = ColorTranslator.FromHtml(value);

                                        int r3, g3, b3;
                                        if (panelColor.R > 85)
                                            r3 = panelColor.R - 170;
                                        else
                                            r3 = panelColor.R + 170;

                                        if (panelColor.G > 85)
                                            g3 = panelColor.G - 170;
                                        else
                                            g3 = panelColor.G + 170;

                                        if (panelColor.B > 85)
                                            b3 = panelColor.B - 170;
                                        else
                                            b3 = panelColor.B + 170;

                                        startButtonColor = Color.FromArgb(r3, g3, b3);
                                    }
                                    catch { }
                                    break;

                                case "taskbuttoncolor":
                                    try
                                    {
                                        taskButtonColor = ColorTranslator.FromHtml(value);
                                        hasTaskButtonColor = true;
                                    }
                                    catch { }
                                    break;

                                case "taskbuttonhovercolor":
                                    try
                                    {
                                        taskButtonHoverColor = ColorTranslator.FromHtml(value);
                                        hasTaskButtonHoverColor = true;
                                    }
                                    catch { }
                                    break;
                            }
                        }
                    }

                    List<string> linesToAdd = new List<string>();

                    if (!hasTaskButtonColor)
                    {
                        linesToAdd.Add("");
                        linesToAdd.Add("taskButtonColor=#FF0000");
                    }

                    if (!hasTaskButtonHoverColor)
                    {
                        linesToAdd.Add("");
                        linesToAdd.Add("taskButtonHoverColor=#0000FF");
                    }

                    if (linesToAdd.Count > 0)
                        File.AppendAllLines(settingsPath, linesToAdd.ToArray());
                }
                else
                {
                    List<string> defaultLines = new List<string>();
                    defaultLines.Add("taskButtonColor=#FF0000");
                    defaultLines.Add("taskButtonHoverColor=#0000FF");
                    File.WriteAllLines(settingsPath, defaultLines.ToArray());
                }
            }
            catch { }
            if (File.Exists("C:\\edit\\blacktext.txt"))
            {
                textColor = Color.Black;
            }
            else
            {
                textColor = Color.White;
            }
            AplajKalrs(this);
        }

        void WireHover(Panel panel, Label label)
        {
            Action enter = () =>
            {
                panel.BackColor = taskButtonHoverColor;
                label.BackColor = taskButtonHoverColor;
            };

            Action leave = () =>
            {
                panel.BackColor = taskButtonColor;
                label.BackColor = taskButtonColor;
            };

            panel.MouseEnter += (s, e) => enter();
            panel.MouseLeave += (s, e) => leave();

            label.MouseEnter += (s, e) => enter();
            label.MouseLeave += (s, e) => leave();
        }
        private void AplajKalrs(Control c)
        {
            WireHover(CloseBtn, CloseLbl);
            WireHover(BigBtn, BigLbl);
            WireHover(MiniBtn, MiniLbl);
            foreach (Control jezevec in c.Controls)
            {
                if ((jezevec is Button))
                {
                    ((Button)jezevec).FlatStyle = FlatStyle.Standard;
                    jezevec.MouseEnter += (s, e) =>
                    {
                        ((Button)jezevec).FlatStyle = FlatStyle.Popup;
                    };
                    jezevec.MouseLeave += (s, e) =>
                    {
                        ((Button)jezevec).FlatStyle = FlatStyle.Standard;
                    };
                }

                if (jezevec.Name == "titlebar" || jezevec.Name == "borderright" || jezevec.Name == "borderleft" || jezevec.Name == "borderbottom" || jezevec.Name == "resize")
                {
                    jezevec.BackColor = panelColor;
                }
                if (jezevec.Name == "titletext")
                {
                    if (File.Exists("C:\\apps\\panel.ps1"))
                    {
                        jezevec.ForeColor = textColor;
                    }
                    else
                    {
                        jezevec.ForeColor = Color.White;
                    }
                }
                if (jezevec.Name == "CloseBtn")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if (jezevec.Name == "BigBtn")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if (jezevec.Name == "MiniBtn")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if (jezevec.Name == "CloseLbl")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if (jezevec.Name == "BigLbl")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if (jezevec.Name == "MiniLbl")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if ((jezevec is Button))
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = panelColor;
                    jezevec.Click += (s, e) =>
                    {
                        if (jezevec.Name != "button1")
                        {
                            this.ActiveControl = WarnLbl;
                        }
                    };
                    jezevec.MouseEnter += (s, e) =>
                    {
                        jezevec.BackColor = taskButtonHoverColor;
                    };
                    jezevec.MouseLeave += (s, e) =>
                    {
                        jezevec.BackColor = panelColor;
                    };
                }

                if (jezevec.HasChildren)
                {
                    AplajKalrs(jezevec);
                }
            }
        }
        private void ResizePanel_MouseDown(object sender, MouseEventArgs e)
        {
            if (isMaximized)
                return;
            if (e.Button == MouseButtons.Left)
            {
                isResizing = true;
                resizeStartMouse = MousePosition;
                resizeStartBounds = this.Bounds;
            }
        }
        private void borderLeft_MouseUp(object sender, MouseEventArgs e)
        {
            if (isMaximized)
                return;
            isResizing = false;
        }

        private void borderLeft_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMaximized)
                return;
            if (isResizing)
            {
                int dx = MousePosition.X - resizeStartMouse.X;
                int newWidth = resizeStartBounds.Width - dx;
                int newLeft = resizeStartBounds.Left + dx;

                if (newWidth > this.MinimumSize.Width)
                {
                    this.Left = newLeft;
                    this.Width = newWidth;
                }
            }
        }

        private void borderRight_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMaximized)
                return;
            if (isResizing)
            {
                int dx = MousePosition.X - resizeStartMouse.X;
                int newWidth = resizeStartBounds.Width + dx;

                if (newWidth > this.MinimumSize.Width)
                    this.Width = newWidth;
            }
        }

        private void borderBottom_MouseMove(object sender, MouseEventArgs e)
        {
            if (isResizing)
            {
                int dy = MousePosition.Y - resizeStartMouse.Y;
                int newHeight = resizeStartBounds.Height + dy;

                if (newHeight > this.MinimumSize.Height)
                    this.Height = newHeight;
            }
        }

        private void resize_MouseMove(object sender, MouseEventArgs e)
        {
            if (isResizing)
            {
                int dx = MousePosition.X - resizeStartMouse.X;
                int dy = MousePosition.Y - resizeStartMouse.Y;

                int newWidth = resizeStartBounds.Width + dx;
                int newHeight = resizeStartBounds.Height + dy;

                if (newWidth > this.MinimumSize.Width)
                    this.Width = newWidth;
                if (newHeight > this.MinimumSize.Height)
                    this.Height = newHeight;
            }
        }

        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);


        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HTCAPTION = 0x2;

        public preparetosave(string path)
        {
            InitializeComponent();
           // this.AutoScaleMode = AutoScaleMode.None;
            //MessageBox.Show("path = " + path);
            imagePath = path;
            try
            {
            if (File.Exists("C:\\apps\\UvikVersionInformation.uvikos"))
                {
                    if (File.ReadAllText("C:\\apps\\UvikVersionInformation.uvikos").Contains("CZ"))
                        cz = true;
                }
            }
            catch
            {
                cz = false; 
            }
            if (cz) { label1.Text = "Snímek pořízen"; } else { label1.Text = "Image captured"; }
            if (cz) { button1.Text = "Zkopírovat do schránky"; } else { button1.Text = "Copy to clipboard"; }
            if (cz) { button2.Text = "Uložit obrázek"; } else { button2.Text = "Save picture"; }
            if (cz) { this.Text = "Uložit soubor"; } else { this.Text = "Save file"; }
            if (cz) { button3.Text = "Smazat obrázek"; } else { button3.Text = "Delete picture"; }
            titlebar.MouseDown += Titlebar_MouseDown;
            titletext.MouseDown += Titlebar_MouseDown;
            WarnTmr = new Timer();
            WarnTmr.Interval = 5000;
            WarnTmr.Tick += (s, e) =>
            {
                WarnLbl.Hide();
                this.Controls.Remove(WarnLbl);
                WarnTmr.Dispose();
            };
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
        }

        private void Titlebar_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && !isMaximized)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            }
        }

        private void Form1_TextChanged(object sender, EventArgs e)
        {
            titletext.Text = this.Text;
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CloseLbl_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MiniBtn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void BigBtn_Click(object sender, EventArgs e)
        {
            if (!isMaximized)
            {
                normalBounds = this.Bounds;
                BigLbl.Text = "2";
                this.Bounds = Screen.FromHandle(this.Handle).WorkingArea;
                isMaximized = true;
                borderleft.Cursor = Cursors.Default;
                borderright.Cursor = Cursors.Default;
                borderbottom.Cursor = Cursors.Default;
                resize.Cursor = Cursors.Default;
            }
            else
            {
                this.Bounds = normalBounds;
                BigLbl.Text = "1";
                isMaximized = false;
                borderleft.Cursor = Cursors.SizeWE;
                borderright.Cursor = Cursors.SizeWE;
                borderbottom.Cursor = Cursors.SizeNS;
                resize.Cursor = Cursors.SizeNWSE;
            }
        }

        // KONEC KÓDU UvíkOS OKEN, VÁŠ KÓD

        private void FormLoaded() // Form1_Load
        {
            try
            {
                if (loadedImage != null)
                {
                    loadedImage.Dispose();
                    loadedImage = null;
                }

                using (Image src = Image.FromFile(imagePath))
                {
                    loadedImage = new Bitmap(src);
                }

                pictureBox1.Image = loadedImage;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Environment.Exit(0);
            }
        }
        Color backColorOfForm = Color.White;
        private bool cz;

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start("mspaint.exe", $"\"{imagePath}\"");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Environment.Exit(0);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (loadedImage == null)
                {
                    MessageBox.Show(cz ? "Žádný obrázek k zkopírování." : "No image to copy.");
                    return;
                }

                Clipboard.SetImage(loadedImage);
                this.ActiveControl = WarnLbl; // aby tlacitka nezustala oznacena
                toolTip1.Show(cz ? "Obrázek zkopírován do schránky." : "Image copied to clipboard.", button1, 5000);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                if (cz) {
                    sfd.Filter = "Obrázek |*.png";
                    sfd.Title = "Uložit obrázek";
                } else
                {
                    sfd.Filter = "Picture |*.png";
                    sfd.Title = "Save picture";
                }
                sfd.FileName = Path.GetFileName(imagePath);

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        if (loadedImage != null)
                        {
                            loadedImage.Save(sfd.FileName, ImageFormat.Png);
                        }
                        else
                        {
                            using (Image src = Image.FromFile(imagePath))
                            using (Bitmap bmp = new Bitmap(src))
                            {
                                bmp.Save(sfd.FileName, ImageFormat.Png);
                            }
                        }

                      
                        try
                        {
                            if (File.Exists(imagePath))
                                File.Delete(imagePath);
                        }
                        catch {}

                        string doentexist = cz ? "Soubor neexistuje: " : "File does not exist: ";

                        if (File.Exists(sfd.FileName))
                        {
                            // /select,"fullpath"
                            ProcessStartInfo psi = new ProcessStartInfo("explorer.exe");
                            psi.Arguments = "/select,\"" + sfd.FileName + "\"";
                            psi.UseShellExecute = true;
                            Process.Start(psi);
                        }
                        else if (Directory.Exists(sfd.FileName))
                        {
                            ProcessStartInfo psi = new ProcessStartInfo("explorer.exe");
                            psi.Arguments = "\"" + sfd.FileName + "\"";
                            psi.UseShellExecute = true;
                            Process.Start(psi);
                        }
                        else
                        {
                            MessageBox.Show(doentexist + sfd.FileName, "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        Environment.Exit(0);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        private void preparetosave_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (pictureBox1.Image != null)
                {
                    pictureBox1.Image = null;
                }

                if (loadedImage != null)
                {
                    loadedImage.Dispose();
                    loadedImage = null;
                }
            }
            catch { }

            Environment.Exit(0);
        }

        private void CloseBtn_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }



        private void button3_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (File.Exists(imagePath))
                    File.Delete(imagePath);
            }
            catch { }
            Environment.Exit(0);
        }
    }
}
