﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace UvikPic
{
    public partial class selectwindow : Form
    {
        private string square;

        [DllImport("user32.dll")]
        static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

        [DllImport("user32.dll")]
        static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll")]
        static extern int GetWindowText(IntPtr hWnd, System.Text.StringBuilder text, int count);

        [DllImport("user32.dll")]
        static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);

        [DllImport("user32.dll")]
        static extern IntPtr GetWindowDC(IntPtr hWnd);

        [DllImport("gdi32.dll")]
        static extern int BitBlt(IntPtr hdcDest, int xDest, int yDest, int w, int h,
                                 IntPtr hdcSrc, int xSrc, int ySrc, int rop);

        [DllImport("user32.dll")]
        static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

        private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        private struct RECT
        {
            public int Left, Top, Right, Bottom;
        }


        // NASTAVENÍ UvíkOS OKEN
        private void CodeSettings()
        {
            isResizable = false;
            isMinimizable = true;
            isBorderless = false;
        }

        // POD TÍMTO ŘÁDKEM ZAČÍNÁ KÓD UvíkOS OKEN

        Color taskButtonColor = Color.White;
        Color taskButtonHoverColor = Color.Blue;
        Color panelColor = Color.Black;
        bool isResizable;
        bool isMinimizable;
        bool isBorderless;
        Color textColor = Color.Black;
        Color startButtonColor;
        bool isMaximized = false;
        private bool isResizing = false;
        private Point resizeStartMouse;
        private Rectangle resizeStartBounds;
        Rectangle normalBounds;
        Timer WarnTmr;
        private void Form1_Load(object sender, EventArgs e)
        {
            CodeSettings();
            FormLoaded();
            titletext.Text = this.Text;
            this.ActiveControl = WarnLbl; // aby tlacitka nezustala oznacena
            if (File.Exists("C:\\apps\\panel.ps1"))
            {
                LoadSettings();
            }
            else
            {
                WarnLbl.Show();
                WarnLbl.BringToFront();
                AplajKalrs(this);

                WarnTmr.Start();
            }
            if (isResizable)
            {
                MakeResizable();
            }
            else
            {
                MakeUnresizable();
            }
            if (!isMinimizable)
            {
                MakeUnminimizable();
            }
            if (isBorderless)
            {
                borderleft.Visible = false;
                borderright.Visible = false;
                borderbottom.Visible = false;
                resize.Visible = false;
                titlebar.Visible = false;
            }
            borderleft.SendToBack();
            borderright.SendToBack();
            borderbottom.SendToBack();
            resize.BringToFront();
            titlebar.SendToBack();
        }
        private void MakeResizable()
        {
            borderleft.MouseDown += ResizePanel_MouseDown;
            borderleft.MouseMove += borderLeft_MouseMove;
            borderleft.MouseUp += borderLeft_MouseUp;

            borderright.MouseDown += ResizePanel_MouseDown;
            borderright.MouseMove += borderRight_MouseMove;
            borderright.MouseUp += borderLeft_MouseUp;

            borderbottom.MouseDown += ResizePanel_MouseDown;
            borderbottom.MouseMove += borderBottom_MouseMove;
            borderbottom.MouseUp += borderLeft_MouseUp;

            resize.MouseDown += ResizePanel_MouseDown;
            resize.MouseMove += resize_MouseMove;
            resize.MouseUp += borderLeft_MouseUp;

            borderleft.Cursor = Cursors.SizeWE;
            borderright.Cursor = Cursors.SizeWE;
            borderbottom.Cursor = Cursors.SizeNS;
            resize.Cursor = Cursors.SizeNWSE;
        }
        private void MakeUnresizable()
        {
            MiniBtn.Location = BigBtn.Location;
            BigBtn.Visible = false;
        }
        private void MakeUnminimizable()
        {
            MiniBtn.Visible = false;
        }
        private void LoadSettings()
        {
            try
            {
                bool hasTaskButtonColor = false;
                bool hasTaskButtonHoverColor = false;

                taskButtonColor = ColorTranslator.FromHtml("#FF0000");
                taskButtonHoverColor = ColorTranslator.FromHtml("#0000FF");

                string settingsPath = @"C:\apps\settings.txt";

                if (File.Exists(settingsPath))
                {
                    string[] lines = File.ReadAllLines(settingsPath);
                    foreach (string line in lines)
                    {
                        string[] parts = line.Split('=');
                        if (parts.Length == 2)
                        {
                            string key = parts[0].Trim().ToLower();
                            string value = parts[1].Trim();

                            switch (key)
                            {
                                case "color":
                                    try
                                    {
                                        panelColor = ColorTranslator.FromHtml(value);

                                        int r3, g3, b3;
                                        if (panelColor.R > 85)
                                            r3 = panelColor.R - 170;
                                        else
                                            r3 = panelColor.R + 170;

                                        if (panelColor.G > 85)
                                            g3 = panelColor.G - 170;
                                        else
                                            g3 = panelColor.G + 170;

                                        if (panelColor.B > 85)
                                            b3 = panelColor.B - 170;
                                        else
                                            b3 = panelColor.B + 170;

                                        startButtonColor = Color.FromArgb(r3, g3, b3);
                                    }
                                    catch { }
                                    break;

                                case "taskbuttoncolor":
                                    try
                                    {
                                        taskButtonColor = ColorTranslator.FromHtml(value);
                                        hasTaskButtonColor = true;
                                    }
                                    catch { }
                                    break;

                                case "taskbuttonhovercolor":
                                    try
                                    {
                                        taskButtonHoverColor = ColorTranslator.FromHtml(value);
                                        hasTaskButtonHoverColor = true;
                                    }
                                    catch { }
                                    break;
                            }
                        }
                    }

                    List<string> linesToAdd = new List<string>();

                    if (!hasTaskButtonColor)
                    {
                        linesToAdd.Add("");
                        linesToAdd.Add("taskButtonColor=#FF0000");
                    }

                    if (!hasTaskButtonHoverColor)
                    {
                        linesToAdd.Add("");
                        linesToAdd.Add("taskButtonHoverColor=#0000FF");
                    }

                    if (linesToAdd.Count > 0)
                        File.AppendAllLines(settingsPath, linesToAdd.ToArray());
                }
                else
                {
                    List<string> defaultLines = new List<string>();
                    defaultLines.Add("taskButtonColor=#FF0000");
                    defaultLines.Add("taskButtonHoverColor=#0000FF");
                    File.WriteAllLines(settingsPath, defaultLines.ToArray());
                }
            }
            catch { }
            if (File.Exists("C:\\edit\\blacktext.txt"))
            {
                textColor = Color.Black;
            }
            else
            {
                textColor = Color.White;
            }
            AplajKalrs(this);
        }

        void WireHover(Panel panel, Label label)
        {
            Action enter = () =>
            {
                panel.BackColor = taskButtonHoverColor;
                label.BackColor = taskButtonHoverColor;
            };

            Action leave = () =>
            {
                panel.BackColor = taskButtonColor;
                label.BackColor = taskButtonColor;
            };

            panel.MouseEnter += (s, e) => enter();
            panel.MouseLeave += (s, e) => leave();

            label.MouseEnter += (s, e) => enter();
            label.MouseLeave += (s, e) => leave();
        }
        private void AplajKalrs(Control c)
        {
            WireHover(CloseBtn, CloseLbl);
            WireHover(BigBtn, BigLbl);
            WireHover(MiniBtn, MiniLbl);
            foreach (Control jezevec in c.Controls)
            {
                if ((jezevec is Button))
                {
                    ((Button)jezevec).FlatStyle = FlatStyle.Standard;
                    jezevec.MouseEnter += (s, e) =>
                    {
                        ((Button)jezevec).FlatStyle = FlatStyle.Popup;
                    };
                    jezevec.MouseLeave += (s, e) =>
                    {
                        ((Button)jezevec).FlatStyle = FlatStyle.Standard;
                    };
                }

                if (jezevec.Name == "titlebar" || jezevec.Name == "borderright" || jezevec.Name == "borderleft" || jezevec.Name == "borderbottom" || jezevec.Name == "resize")
                {
                    jezevec.BackColor = panelColor;
                }
                if (jezevec.Name == "titletext")
                {
                    if (File.Exists("C:\\apps\\panel.ps1"))
                    {
                        jezevec.ForeColor = textColor;
                    }
                    else
                    {
                        jezevec.ForeColor = Color.White;
                    }
                }
                if (jezevec.Name == "CloseBtn")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if (jezevec.Name == "BigBtn")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if (jezevec.Name == "MiniBtn")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if (jezevec.Name == "CloseLbl")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if (jezevec.Name == "BigLbl")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if (jezevec.Name == "MiniLbl")
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = taskButtonColor;
                }
                if ((jezevec is Button))
                {
                    jezevec.ForeColor = textColor;
                    jezevec.BackColor = panelColor;
                    jezevec.Click += (s, e) =>
                    {
                        if (jezevec.Name != "button5")
                        {
                            this.ActiveControl = WarnLbl;
                        }
                    };
                    jezevec.MouseEnter += (s, e) =>
                    {
                        jezevec.BackColor = taskButtonHoverColor;
                    };
                    jezevec.MouseLeave += (s, e) =>
                    {
                        jezevec.BackColor = panelColor;
                    };
                }

                if (jezevec.HasChildren)
                {
                    AplajKalrs(jezevec);
                }
            }
        }
        private void ResizePanel_MouseDown(object sender, MouseEventArgs e)
        {
            if (isMaximized)
                return;
            if (e.Button == MouseButtons.Left)
            {
                isResizing = true;
                resizeStartMouse = MousePosition;
                resizeStartBounds = this.Bounds;
            }
        }
        private void borderLeft_MouseUp(object sender, MouseEventArgs e)
        {
            if (isMaximized)
                return;
            isResizing = false;
        }

        private void borderLeft_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMaximized)
                return;
            if (isResizing)
            {
                int dx = MousePosition.X - resizeStartMouse.X;
                int newWidth = resizeStartBounds.Width - dx;
                int newLeft = resizeStartBounds.Left + dx;

                if (newWidth > this.MinimumSize.Width)
                {
                    this.Left = newLeft;
                    this.Width = newWidth;
                }
            }
        }

        private void borderRight_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMaximized)
                return;
            if (isResizing)
            {
                int dx = MousePosition.X - resizeStartMouse.X;
                int newWidth = resizeStartBounds.Width + dx;

                if (newWidth > this.MinimumSize.Width)
                    this.Width = newWidth;
            }
        }

        private void borderBottom_MouseMove(object sender, MouseEventArgs e)
        {
            if (isResizing)
            {
                int dy = MousePosition.Y - resizeStartMouse.Y;
                int newHeight = resizeStartBounds.Height + dy;

                if (newHeight > this.MinimumSize.Height)
                    this.Height = newHeight;
            }
        }

        private void resize_MouseMove(object sender, MouseEventArgs e)
        {
            if (isResizing)
            {
                int dx = MousePosition.X - resizeStartMouse.X;
                int dy = MousePosition.Y - resizeStartMouse.Y;

                int newWidth = resizeStartBounds.Width + dx;
                int newHeight = resizeStartBounds.Height + dy;

                if (newWidth > this.MinimumSize.Width)
                    this.Width = newWidth;
                if (newHeight > this.MinimumSize.Height)
                    this.Height = newHeight;
            }
        }

        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);


        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HTCAPTION = 0x2;

        public selectwindow()
        {
            if (File.ReadAllText("C:\\apps\\UvikVersionInformation.uvikos").Contains("CZ"))
            {
                cz = true;
            }
            
            InitializeComponent();
            if (cz) { label1.Text = "Vyberte okno ze seznamu"; } else { label1.Text = "Select a window"; }
            if (cz) { button3.Text = "Pořídit"; } else { button3.Text = "Capture"; }
            if (cz) { square = "Označit čtverec"; } else { square = "Select square"; }
            titlebar.MouseDown += Titlebar_MouseDown;
            titletext.MouseDown += Titlebar_MouseDown;
            WarnTmr = new Timer();
            WarnTmr.Interval = 5000;
            WarnTmr.Tick += (s, e) =>
            {
                WarnLbl.Hide();
                this.Controls.Remove(WarnLbl);
                WarnTmr.Dispose();
            };
        }

        private void Titlebar_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && !isMaximized)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            }
        }

        private void Form1_TextChanged(object sender, EventArgs e)
        {
            titletext.Text = this.Text;
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CloseLbl_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MiniBtn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private string GenerateSavePath()
        {
            string folder = @"C:\edit\personal";
            Directory.CreateDirectory(folder);

            Random rnd = new Random();
            string path;

            do
            {
                int num = rnd.Next(0, 1000);
                path = Path.Combine(folder, $"snimek{num}.png");
            }
            while (File.Exists(path));

            return path;
        }


        private Bitmap CaptureWindow(IntPtr hWnd)
        {
            GetWindowRect(hWnd, out RECT rect);

            int width = rect.Right - rect.Left;
            int height = rect.Bottom - rect.Top;

            Bitmap bmp = new Bitmap(width, height);
            Graphics g = Graphics.FromImage(bmp);

            IntPtr hdcDest = g.GetHdc();
            IntPtr hdcSrc = GetWindowDC(hWnd);

            BitBlt(hdcDest, 0, 0, width, height, hdcSrc, 0, 0, 0x00CC0020);

            g.ReleaseHdc(hdcDest);
            ReleaseDC(hWnd, hdcSrc);
            g.Dispose();

            return bmp;
        }


        private void BigBtn_Click(object sender, EventArgs e)
        {
            if (!isMaximized)
            {
                normalBounds = this.Bounds;
                BigLbl.Text = "2";
                this.Bounds = Screen.FromHandle(this.Handle).WorkingArea;
                isMaximized = true;
                borderleft.Cursor = Cursors.Default;
                borderright.Cursor = Cursors.Default;
                borderbottom.Cursor = Cursors.Default;
                resize.Cursor = Cursors.Default;
            }
            else
            {
                this.Bounds = normalBounds;
                BigLbl.Text = "1";
                isMaximized = false;
                borderleft.Cursor = Cursors.SizeWE;
                borderright.Cursor = Cursors.SizeWE;
                borderbottom.Cursor = Cursors.SizeNS;
                resize.Cursor = Cursors.SizeNWSE;
            }
        }

        // KONEC KÓDU UvíkOS OKEN, VÁŠ KÓD

        private void FormLoaded() // Form1_Load
        {
            listBox1.Items.Clear();

            EnumWindows((hWnd, lParam) =>
            {
                if (IsWindowVisible(hWnd))
                {
                    var sb = new System.Text.StringBuilder(256);
                    GetWindowText(hWnd, sb, sb.Capacity);

                    string title = sb.ToString();

                    if (!string.IsNullOrWhiteSpace(title))
                    {
                        listBox1.Items.Add(new WindowItem(title, hWnd));
                    }
                }
                return true;
            }, IntPtr.Zero);
        }
        Color backColorOfForm = Color.White;
        private bool cz;

        private class WindowItem
        {
            public string Title { get; set; }
            public IntPtr Handle { get; set; }

            public WindowItem(string title, IntPtr handle)
            {
                Title = title;
                Handle = handle;
            }

            public override string ToString() => Title;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem is WindowItem item)
            {
                Bitmap bmp = CaptureWindow(item.Handle);
                string path = GenerateSavePath();

                bmp.Save(path, System.Drawing.Imaging.ImageFormat.Png);
                bmp.Dispose();

                // otevřít preparetosave
                preparetosave pts = new preparetosave(path);
                pts.Show();

                this.Close();
            }
            else
            {
                MessageBox.Show(square);
            }
        }

        private void selectwindow_FormClosing(object sender, FormClosingEventArgs e)
        {
           // Environment.Exit(0);
        }
    }
}
