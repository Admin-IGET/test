﻿
namespace UvikPic
{
    partial class UvikForm1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UvikForm1));
            this.titlebar = new System.Windows.Forms.Panel();
            this.SnippingToolBtn = new System.Windows.Forms.Panel();
            this.MiniBtn = new System.Windows.Forms.Panel();
            this.MiniLbl = new System.Windows.Forms.Label();
            this.BigBtn = new System.Windows.Forms.Panel();
            this.BigLbl = new System.Windows.Forms.Label();
            this.CloseBtn = new System.Windows.Forms.Panel();
            this.CloseLbl = new System.Windows.Forms.Label();
            this.titletext = new System.Windows.Forms.Label();
            this.borderleft = new System.Windows.Forms.Panel();
            this.borderright = new System.Windows.Forms.Panel();
            this.borderbottom = new System.Windows.Forms.Panel();
            this.resize = new System.Windows.Forms.Panel();
            this.WarnLbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.directoryField = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.filenameField = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.titlebar.SuspendLayout();
            this.MiniBtn.SuspendLayout();
            this.BigBtn.SuspendLayout();
            this.CloseBtn.SuspendLayout();
            this.SuspendLayout();
            // 
            // titlebar
            // 
            this.titlebar.BackColor = System.Drawing.Color.Black;
            this.titlebar.Controls.Add(this.SnippingToolBtn);
            this.titlebar.Controls.Add(this.MiniBtn);
            this.titlebar.Controls.Add(this.BigBtn);
            this.titlebar.Controls.Add(this.CloseBtn);
            this.titlebar.Controls.Add(this.titletext);
            this.titlebar.Dock = System.Windows.Forms.DockStyle.Top;
            this.titlebar.Location = new System.Drawing.Point(0, 0);
            this.titlebar.Name = "titlebar";
            this.titlebar.Size = new System.Drawing.Size(439, 32);
            this.titlebar.TabIndex = 0;
            // 
            // SnippingToolBtn
            // 
            this.SnippingToolBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.SnippingToolBtn.BackColor = System.Drawing.Color.White;
            this.SnippingToolBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SnippingToolBtn.BackgroundImage")));
            this.SnippingToolBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SnippingToolBtn.Location = new System.Drawing.Point(340, 1);
            this.SnippingToolBtn.Name = "SnippingToolBtn";
            this.SnippingToolBtn.Size = new System.Drawing.Size(30, 30);
            this.SnippingToolBtn.TabIndex = 7;
            this.SnippingToolBtn.Click += new System.EventHandler(this.SnippingToolBtn_Click);
            this.SnippingToolBtn.Paint += new System.Windows.Forms.PaintEventHandler(this.SnippingToolBtn_Paint);
            this.SnippingToolBtn.MouseEnter += new System.EventHandler(this.SnippingToolBtn_MouseEnter);
            this.SnippingToolBtn.MouseLeave += new System.EventHandler(this.SnippingToolBtn_MouseLeave);
            // 
            // MiniBtn
            // 
            this.MiniBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MiniBtn.BackColor = System.Drawing.Color.White;
            this.MiniBtn.Controls.Add(this.MiniLbl);
            this.MiniBtn.Location = new System.Drawing.Point(340, 1);
            this.MiniBtn.Name = "MiniBtn";
            this.MiniBtn.Size = new System.Drawing.Size(30, 30);
            this.MiniBtn.TabIndex = 6;
            this.MiniBtn.Click += new System.EventHandler(this.MiniBtn_Click);
            // 
            // MiniLbl
            // 
            this.MiniLbl.AutoSize = true;
            this.MiniLbl.Font = new System.Drawing.Font("Marlett", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.MiniLbl.Location = new System.Drawing.Point(4, 8);
            this.MiniLbl.Name = "MiniLbl";
            this.MiniLbl.Size = new System.Drawing.Size(23, 15);
            this.MiniLbl.TabIndex = 4;
            this.MiniLbl.Text = "q";
            this.MiniLbl.Click += new System.EventHandler(this.MiniBtn_Click);
            // 
            // BigBtn
            // 
            this.BigBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BigBtn.BackColor = System.Drawing.Color.White;
            this.BigBtn.Controls.Add(this.BigLbl);
            this.BigBtn.Location = new System.Drawing.Point(372, 1);
            this.BigBtn.Name = "BigBtn";
            this.BigBtn.Size = new System.Drawing.Size(30, 30);
            this.BigBtn.TabIndex = 5;
            this.BigBtn.Click += new System.EventHandler(this.BigBtn_Click);
            // 
            // BigLbl
            // 
            this.BigLbl.AutoSize = true;
            this.BigLbl.Font = new System.Drawing.Font("Marlett", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.BigLbl.Location = new System.Drawing.Point(5, 9);
            this.BigLbl.Name = "BigLbl";
            this.BigLbl.Size = new System.Drawing.Size(21, 13);
            this.BigLbl.TabIndex = 4;
            this.BigLbl.Text = "1";
            this.BigLbl.Click += new System.EventHandler(this.BigBtn_Click);
            // 
            // CloseBtn
            // 
            this.CloseBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CloseBtn.BackColor = System.Drawing.Color.White;
            this.CloseBtn.Controls.Add(this.CloseLbl);
            this.CloseBtn.Location = new System.Drawing.Point(404, 1);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(30, 30);
            this.CloseBtn.TabIndex = 4;
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // CloseLbl
            // 
            this.CloseLbl.AutoSize = true;
            this.CloseLbl.Font = new System.Drawing.Font("Marlett", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.CloseLbl.Location = new System.Drawing.Point(5, 9);
            this.CloseLbl.Name = "CloseLbl";
            this.CloseLbl.Size = new System.Drawing.Size(21, 13);
            this.CloseLbl.TabIndex = 4;
            this.CloseLbl.Text = "r";
            this.CloseLbl.Click += new System.EventHandler(this.CloseLbl_Click);
            // 
            // titletext
            // 
            this.titletext.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.titletext.AutoEllipsis = true;
            this.titletext.BackColor = System.Drawing.Color.Transparent;
            this.titletext.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titletext.ForeColor = System.Drawing.Color.White;
            this.titletext.Location = new System.Drawing.Point(13, 1);
            this.titletext.Name = "titletext";
            this.titletext.Size = new System.Drawing.Size(321, 30);
            this.titletext.TabIndex = 0;
            this.titletext.Text = "Snímek obrazovky";
            this.titletext.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // borderleft
            // 
            this.borderleft.BackColor = System.Drawing.Color.Black;
            this.borderleft.Dock = System.Windows.Forms.DockStyle.Left;
            this.borderleft.Location = new System.Drawing.Point(0, 32);
            this.borderleft.Margin = new System.Windows.Forms.Padding(0);
            this.borderleft.Name = "borderleft";
            this.borderleft.Size = new System.Drawing.Size(5, 129);
            this.borderleft.TabIndex = 2;
            // 
            // borderright
            // 
            this.borderright.BackColor = System.Drawing.Color.Black;
            this.borderright.Dock = System.Windows.Forms.DockStyle.Right;
            this.borderright.Location = new System.Drawing.Point(434, 32);
            this.borderright.Margin = new System.Windows.Forms.Padding(0);
            this.borderright.Name = "borderright";
            this.borderright.Size = new System.Drawing.Size(5, 129);
            this.borderright.TabIndex = 3;
            // 
            // borderbottom
            // 
            this.borderbottom.BackColor = System.Drawing.Color.Black;
            this.borderbottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.borderbottom.Location = new System.Drawing.Point(5, 156);
            this.borderbottom.Margin = new System.Windows.Forms.Padding(0);
            this.borderbottom.Name = "borderbottom";
            this.borderbottom.Size = new System.Drawing.Size(429, 5);
            this.borderbottom.TabIndex = 3;
            // 
            // resize
            // 
            this.resize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.resize.BackColor = System.Drawing.Color.Black;
            this.resize.Location = new System.Drawing.Point(434, 156);
            this.resize.Margin = new System.Windows.Forms.Padding(0);
            this.resize.Name = "resize";
            this.resize.Size = new System.Drawing.Size(5, 5);
            this.resize.TabIndex = 4;
            // 
            // WarnLbl
            // 
            this.WarnLbl.AutoSize = true;
            this.WarnLbl.BackColor = System.Drawing.Color.Transparent;
            this.WarnLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WarnLbl.ForeColor = System.Drawing.Color.Red;
            this.WarnLbl.Location = new System.Drawing.Point(12, -58);
            this.WarnLbl.Name = "WarnLbl";
            this.WarnLbl.Size = new System.Drawing.Size(265, 39);
            this.WarnLbl.TabIndex = 5;
            this.WarnLbl.Text = "Nelze načíst nastavení UvíkOS. \r\nDůvod : soubor C:\\apps\\panel.ps1 neexistuje\r\nOpr" +
    "ava : nainstalujte si UvíkOS!";
            this.WarnLbl.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 18);
            this.label1.TabIndex = 6;
            this.label1.Text = "label1Text";
            // 
            // directoryField
            // 
            this.directoryField.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.directoryField.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.directoryField.Location = new System.Drawing.Point(80, 34);
            this.directoryField.Name = "directoryField";
            this.directoryField.Size = new System.Drawing.Size(263, 21);
            this.directoryField.TabIndex = 7;
            this.directoryField.Text = "C:\\edit\\personal";
            this.directoryField.TextChanged += new System.EventHandler(this.directoryField_TextChanged);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Location = new System.Drawing.Point(346, 34);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(64, 21);
            this.button1.TabIndex = 8;
            this.button1.Text = "btn1Text";
            this.button1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.browseButton_Click);
            // 
            // filenameField
            // 
            this.filenameField.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.filenameField.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.filenameField.Location = new System.Drawing.Point(80, 59);
            this.filenameField.Name = "filenameField";
            this.filenameField.Size = new System.Drawing.Size(330, 21);
            this.filenameField.TabIndex = 10;
            this.filenameField.Text = "filename";
            this.filenameField.TextChanged += new System.EventHandler(this.filenameField_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 18);
            this.label2.TabIndex = 9;
            this.label2.Text = "label2Text";
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(134, 86);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(220, 49);
            this.button3.TabIndex = 12;
            this.button3.Text = "Pořídit snímek obrazovky";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.screenshotButton_Click);
            // 
            // UvikForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(439, 161);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.filenameField);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.directoryField);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.WarnLbl);
            this.Controls.Add(this.resize);
            this.Controls.Add(this.borderbottom);
            this.Controls.Add(this.borderright);
            this.Controls.Add(this.borderleft);
            this.Controls.Add(this.titlebar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(218, 128);
            this.Name = "UvikForm1";
            this.Text = "titleText";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.TextChanged += new System.EventHandler(this.Form1_TextChanged);
            this.titlebar.ResumeLayout(false);
            this.MiniBtn.ResumeLayout(false);
            this.MiniBtn.PerformLayout();
            this.BigBtn.ResumeLayout(false);
            this.BigBtn.PerformLayout();
            this.CloseBtn.ResumeLayout(false);
            this.CloseBtn.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel titlebar;
        private System.Windows.Forms.Label titletext;
        private System.Windows.Forms.Panel borderleft;
        private System.Windows.Forms.Panel borderright;
        private System.Windows.Forms.Panel borderbottom;
        private System.Windows.Forms.Panel CloseBtn;
        private System.Windows.Forms.Label CloseLbl;
        private System.Windows.Forms.Panel MiniBtn;
        private System.Windows.Forms.Label MiniLbl;
        private System.Windows.Forms.Panel BigBtn;
        private System.Windows.Forms.Label BigLbl;
        private System.Windows.Forms.Panel resize;
        private System.Windows.Forms.Label WarnLbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox directoryField;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox filenameField;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel SnippingToolBtn;
    }
}

