﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UvikPic
{
    public partial class ScreenCapture : Form
    {
        private Point startPoint;
        private Rectangle selectionRect;
        private bool isSelecting = false;
        private string savePath;
        private Bitmap screenshot;
        private Bitmap displayScreenshot;
        [DllImport("user32.dll")]
        static extern IntPtr SetThreadDpiAwarenessContext(IntPtr dpiContext);

        static readonly IntPtr DPI_UNAWARE = new IntPtr(-1);
        static readonly IntPtr DPI_AWARE = new IntPtr(-2);
        static readonly IntPtr DPI_PER_MONITOR_AWARE_V2 = new IntPtr(-4);
        public ScreenCapture()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
            this.TopMost = true;
            TakeScreenshot();
            this.Cursor = Cursors.Cross;
            //this.savePath = savePath;
            SetThreadDpiAwarenessContext(DPI_PER_MONITOR_AWARE_V2);
        }
        private void TakeScreenshot()
        {
            Rectangle bounds = Screen.PrimaryScreen.Bounds;

            this.Hide();
            Application.DoEvents();

            screenshot = new Bitmap(bounds.Width, bounds.Height);

            using (Graphics g = Graphics.FromImage(screenshot))
            {
                g.CopyFromScreen(Point.Empty, Point.Empty, bounds.Size);
            }

            displayScreenshot = new Bitmap(screenshot.Width, screenshot.Height);

            using (Graphics g = Graphics.FromImage(displayScreenshot))
            {
                g.DrawImage(screenshot, 0, 0);

                using (Brush b = new SolidBrush(Color.FromArgb(150, Color.Black)))
                {
                    g.FillRectangle(b, 0, 0, displayScreenshot.Width, displayScreenshot.Height);
                }
            }

            this.Show();
        }
        private void CaptureAndSave(Rectangle rect) //Ano to je AI ale už to je staré z roku 2025 z mého staráho projektu a je to funkční takže to nechci měnit protože if it works don't fix it
        {
            // Neprovádět capture s overlayem viditelným — skryjeme form, převedeme souřadnice na screen a pak zachytíme
            if (rect.Width <= 0 || rect.Height <= 0)
            {
                MessageBox.Show("Neplatná oblast pro snímek.");
                Environment.Exit(0);
            }

            // Převod z klientských souřadnic formu na souřadnice obrazovky
            Point screenLocation = this.PointToScreen(rect.Location);
            Rectangle screenRect = new Rectangle(screenLocation, rect.Size);

            bool wasVisible = this.Visible;
            this.Hide();
            Application.DoEvents(); // zajistí, že okno zmizí před capture

            try
            {
                string path = GenerateSavePath();

                using (Bitmap bmp = new Bitmap(screenRect.Width, screenRect.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb))
                {
                    using (Graphics g = Graphics.FromImage(bmp))
                    {
                        g.CopyFromScreen(screenRect.Location, Point.Empty, screenRect.Size, CopyPixelOperation.SourceCopy);
                    }

                    bmp.Save(path, System.Drawing.Imaging.ImageFormat.Png);
                }
                var old = SetThreadDpiAwarenessContext(DPI_UNAWARE);
                preparetosave pts = new preparetosave(path);
                pts.Show();
                SetThreadDpiAwarenessContext(old);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Uvík si nechal kameru doma: " + ex.Message);
            }
            finally
            {
                if (wasVisible)
                {
                    this.Show();
                    Application.DoEvents();
                }
            }
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isSelecting = true;
                startPoint = e.Location;
                selectionRect = new Rectangle(e.Location, new Size(0, 0));
                Invalidate();
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (isSelecting)
            {
                int x = Math.Min(startPoint.X, e.X);
                int y = Math.Min(startPoint.Y, e.Y);
                int width = Math.Abs(startPoint.X - e.X);
                int height = Math.Abs(startPoint.Y - e.Y);
                selectionRect = new Rectangle(x, y, width, height);
                Invalidate();
            }
        }

        private string GenerateSavePath()
        {
            string folder = @"C:\edit\personal";
            Directory.CreateDirectory(folder);

            Random rnd = new Random();
            string path;

            do
            {
                int num = rnd.Next(0, 1000);
                path = Path.Combine(folder, $"snimek{num}.png");
            }
            while (File.Exists(path));

            return path;
        }


        protected override void OnPaint(PaintEventArgs e)
        {
            if (displayScreenshot != null)
                e.Graphics.DrawImage(displayScreenshot, 0, 0);

            if (isSelecting)
            {
                using (Pen pen = new Pen(Color.Red, 2))
                {
                    e.Graphics.DrawRectangle(pen, selectionRect);
                }
            }
        }



        protected override void OnMouseUp(MouseEventArgs e)
        {
            if (isSelecting)
            {
                isSelecting = false;
                CaptureAndSave(selectionRect);
                this.Close();
            }
        }

        private void ScreenCapture_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void ScreenCapture_FormClosing(object sender, FormClosingEventArgs e)
        {
         //   Environment.Exit(0);
        }
    }
}
