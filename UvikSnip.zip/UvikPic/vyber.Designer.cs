﻿
namespace UvikPic
{
    partial class vyber
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.titlebar = new System.Windows.Forms.Panel();
            this.MiniBtn = new System.Windows.Forms.Panel();
            this.MiniLbl = new System.Windows.Forms.Label();
            this.BigBtn = new System.Windows.Forms.Panel();
            this.BigLbl = new System.Windows.Forms.Label();
            this.CloseBtn = new System.Windows.Forms.Panel();
            this.CloseLbl = new System.Windows.Forms.Label();
            this.titletext = new System.Windows.Forms.Label();
            this.borderleft = new System.Windows.Forms.Panel();
            this.borderright = new System.Windows.Forms.Panel();
            this.borderbottom = new System.Windows.Forms.Panel();
            this.resize = new System.Windows.Forms.Panel();
            this.WarnLbl = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.titlebar.SuspendLayout();
            this.MiniBtn.SuspendLayout();
            this.BigBtn.SuspendLayout();
            this.CloseBtn.SuspendLayout();
            this.SuspendLayout();
            // 
            // titlebar
            // 
            this.titlebar.BackColor = System.Drawing.Color.Black;
            this.titlebar.Controls.Add(this.MiniBtn);
            this.titlebar.Controls.Add(this.BigBtn);
            this.titlebar.Controls.Add(this.CloseBtn);
            this.titlebar.Controls.Add(this.titletext);
            this.titlebar.Dock = System.Windows.Forms.DockStyle.Top;
            this.titlebar.Location = new System.Drawing.Point(0, 0);
            this.titlebar.Name = "titlebar";
            this.titlebar.Size = new System.Drawing.Size(516, 32);
            this.titlebar.TabIndex = 0;
            // 
            // MiniBtn
            // 
            this.MiniBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MiniBtn.BackColor = System.Drawing.Color.White;
            this.MiniBtn.Controls.Add(this.MiniLbl);
            this.MiniBtn.Location = new System.Drawing.Point(417, 1);
            this.MiniBtn.Name = "MiniBtn";
            this.MiniBtn.Size = new System.Drawing.Size(30, 30);
            this.MiniBtn.TabIndex = 6;
            this.MiniBtn.Click += new System.EventHandler(this.MiniBtn_Click);
            // 
            // MiniLbl
            // 
            this.MiniLbl.AutoSize = true;
            this.MiniLbl.Font = new System.Drawing.Font("Marlett", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.MiniLbl.Location = new System.Drawing.Point(4, 8);
            this.MiniLbl.Name = "MiniLbl";
            this.MiniLbl.Size = new System.Drawing.Size(23, 15);
            this.MiniLbl.TabIndex = 5;
            this.MiniLbl.Text = "q";
            this.MiniLbl.Click += new System.EventHandler(this.MiniBtn_Click);
            // 
            // BigBtn
            // 
            this.BigBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BigBtn.BackColor = System.Drawing.Color.White;
            this.BigBtn.Controls.Add(this.BigLbl);
            this.BigBtn.Location = new System.Drawing.Point(449, 1);
            this.BigBtn.Name = "BigBtn";
            this.BigBtn.Size = new System.Drawing.Size(30, 30);
            this.BigBtn.TabIndex = 5;
            this.BigBtn.Click += new System.EventHandler(this.BigBtn_Click);
            // 
            // BigLbl
            // 
            this.BigLbl.AutoSize = true;
            this.BigLbl.Font = new System.Drawing.Font("Marlett", 10.75F, System.Drawing.FontStyle.Bold);
            this.BigLbl.Location = new System.Drawing.Point(5, 8);
            this.BigLbl.Name = "BigLbl";
            this.BigLbl.Size = new System.Drawing.Size(23, 15);
            this.BigLbl.TabIndex = 5;
            this.BigLbl.Text = "1";
            this.BigLbl.Click += new System.EventHandler(this.BigBtn_Click);
            // 
            // CloseBtn
            // 
            this.CloseBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CloseBtn.BackColor = System.Drawing.Color.White;
            this.CloseBtn.Controls.Add(this.CloseLbl);
            this.CloseBtn.Location = new System.Drawing.Point(481, 1);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(30, 30);
            this.CloseBtn.TabIndex = 4;
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // CloseLbl
            // 
            this.CloseLbl.AutoSize = true;
            this.CloseLbl.Font = new System.Drawing.Font("Marlett", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.CloseLbl.Location = new System.Drawing.Point(5, 9);
            this.CloseLbl.Name = "CloseLbl";
            this.CloseLbl.Size = new System.Drawing.Size(21, 13);
            this.CloseLbl.TabIndex = 5;
            this.CloseLbl.Text = "r";
            this.CloseLbl.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // titletext
            // 
            this.titletext.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.titletext.AutoEllipsis = true;
            this.titletext.BackColor = System.Drawing.Color.Transparent;
            this.titletext.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titletext.ForeColor = System.Drawing.Color.White;
            this.titletext.Location = new System.Drawing.Point(13, 1);
            this.titletext.Name = "titletext";
            this.titletext.Size = new System.Drawing.Size(398, 30);
            this.titletext.TabIndex = 0;
            this.titletext.Text = "Jméno okna";
            this.titletext.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // borderleft
            // 
            this.borderleft.BackColor = System.Drawing.Color.Black;
            this.borderleft.Dock = System.Windows.Forms.DockStyle.Left;
            this.borderleft.Location = new System.Drawing.Point(0, 32);
            this.borderleft.Margin = new System.Windows.Forms.Padding(0);
            this.borderleft.Name = "borderleft";
            this.borderleft.Size = new System.Drawing.Size(5, 241);
            this.borderleft.TabIndex = 2;
            // 
            // borderright
            // 
            this.borderright.BackColor = System.Drawing.Color.Black;
            this.borderright.Dock = System.Windows.Forms.DockStyle.Right;
            this.borderright.Location = new System.Drawing.Point(511, 32);
            this.borderright.Margin = new System.Windows.Forms.Padding(0);
            this.borderright.Name = "borderright";
            this.borderright.Size = new System.Drawing.Size(5, 241);
            this.borderright.TabIndex = 3;
            // 
            // borderbottom
            // 
            this.borderbottom.BackColor = System.Drawing.Color.Black;
            this.borderbottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.borderbottom.Location = new System.Drawing.Point(5, 268);
            this.borderbottom.Margin = new System.Windows.Forms.Padding(0);
            this.borderbottom.Name = "borderbottom";
            this.borderbottom.Size = new System.Drawing.Size(506, 5);
            this.borderbottom.TabIndex = 3;
            // 
            // resize
            // 
            this.resize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.resize.BackColor = System.Drawing.Color.Black;
            this.resize.Location = new System.Drawing.Point(511, 268);
            this.resize.Margin = new System.Windows.Forms.Padding(0);
            this.resize.Name = "resize";
            this.resize.Size = new System.Drawing.Size(5, 5);
            this.resize.TabIndex = 4;
            // 
            // WarnLbl
            // 
            this.WarnLbl.AutoSize = true;
            this.WarnLbl.BackColor = System.Drawing.Color.Transparent;
            this.WarnLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WarnLbl.ForeColor = System.Drawing.SystemColors.Control;
            this.WarnLbl.Location = new System.Drawing.Point(12, 36);
            this.WarnLbl.Name = "WarnLbl";
            this.WarnLbl.Size = new System.Drawing.Size(265, 39);
            this.WarnLbl.TabIndex = 5;
            this.WarnLbl.Text = "Nelze načíst nastavení UvíkOS. \r\nDůvod : soubor C:\\apps\\panel.ps1 neexistuje\r\nOpr" +
    "ava : nainstalujte si UvíkOS!";
            this.WarnLbl.Visible = false;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(130, 38);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(220, 49);
            this.button3.TabIndex = 13;
            this.button3.Text = "Označit obrazovku";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(130, 124);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(220, 49);
            this.button1.TabIndex = 14;
            this.button1.Text = "Vybrat okno";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(130, 212);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(220, 49);
            this.button2.TabIndex = 15;
            this.button2.Text = "Celá obrazovka";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // vyber
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(516, 273);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.WarnLbl);
            this.Controls.Add(this.resize);
            this.Controls.Add(this.borderbottom);
            this.Controls.Add(this.borderright);
            this.Controls.Add(this.borderleft);
            this.Controls.Add(this.titlebar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimumSize = new System.Drawing.Size(218, 128);
            this.Name = "vyber";
            this.Text = "Snímek obrazovky";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.TextChanged += new System.EventHandler(this.Form1_TextChanged);
            this.titlebar.ResumeLayout(false);
            this.MiniBtn.ResumeLayout(false);
            this.MiniBtn.PerformLayout();
            this.BigBtn.ResumeLayout(false);
            this.BigBtn.PerformLayout();
            this.CloseBtn.ResumeLayout(false);
            this.CloseBtn.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel titlebar;
        private System.Windows.Forms.Label titletext;
        private System.Windows.Forms.Panel borderleft;
        private System.Windows.Forms.Panel borderright;
        private System.Windows.Forms.Panel borderbottom;
        private System.Windows.Forms.Panel CloseBtn;
        private System.Windows.Forms.Panel MiniBtn;
        private System.Windows.Forms.Panel BigBtn;
        private System.Windows.Forms.Panel resize;
        private System.Windows.Forms.Label WarnLbl;
        private System.Windows.Forms.Label MiniLbl;
        private System.Windows.Forms.Label BigLbl;
        private System.Windows.Forms.Label CloseLbl;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

