﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

namespace UvikPic
{
    public partial class CircleCapture : Form
    {
        private Bitmap screenshot;
        private Point circleCenter;
        private int circleRadius = 0;
        private bool drawing = false;

        public CircleCapture()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;
            this.TopMost = true;
        }

        

        private void TakeDarkenedScreenshot()
        {
            Rectangle bounds = Screen.PrimaryScreen.Bounds;
            screenshot = new Bitmap(bounds.Width, bounds.Height);

            using (Graphics g = Graphics.FromImage(screenshot))
            {
                g.CopyFromScreen(Point.Empty, Point.Empty, bounds.Size);

                // Ztmavení screenshotu
                using (Brush b = new SolidBrush(Color.FromArgb(150, Color.Black)))
                {
                    g.FillRectangle(b, 0, 0, bounds.Width, bounds.Height);
                }
            }
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            drawing = true;
            circleCenter = e.Location;
            circleRadius = 0;
            Invalidate();
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (drawing)
            {
                circleRadius = (int)Math.Sqrt(
                    Math.Pow(e.X - circleCenter.X, 2) +
                    Math.Pow(e.Y - circleCenter.Y, 2)
                );
                Invalidate();
            }
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            drawing = false;
            SaveFinalImage();
            this.Close();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (screenshot != null)
                e.Graphics.DrawImage(screenshot, 0, 0);

            if (circleRadius > 0)
            {
                using (Pen p = new Pen(Color.Red, 3))
                {
                    e.Graphics.DrawEllipse(
                        p,
                        circleCenter.X - circleRadius,
                        circleCenter.Y - circleRadius,
                        circleRadius * 2,
                        circleRadius * 2
                    );
                }
            }
        }

        private void SaveFinalImage()
        {
            string folder = @"C:\edit\personal";
            Directory.CreateDirectory(folder);

            Random rnd = new Random();
            string path;

            do
            {
                int num = rnd.Next(0, 1000);
                path = Path.Combine(folder, $"snimek{num}.png");
            }
            while (File.Exists(path));

            int diameter = circleRadius * 2;

            // Výsledný obrázek bude přesně velikost kruhu
            Bitmap output = new Bitmap(diameter, diameter, PixelFormat.Format32bppArgb);

            using (Graphics g = Graphics.FromImage(output))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

                // Vyříznutí kruhu pomocí masky
                using (GraphicsPath pathCircle = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    pathCircle.AddEllipse(0, 0, diameter, diameter);
                    g.SetClip(pathCircle);

                    // Přenesení části screenshotu do výřezu
                    g.DrawImage(
                        screenshot,
                        new Rectangle(0, 0, diameter, diameter),
                        new Rectangle(circleCenter.X - circleRadius, circleCenter.Y - circleRadius, diameter, diameter),
                        GraphicsUnit.Pixel
                    );
                }
            }

            


            output.Save(path, ImageFormat.Png);
            preparetosave pts = new preparetosave(path);
            pts.Show();
            output.Dispose();
        }


        private void CircleCapture_Load(object sender, EventArgs e)
        {
            TakeDarkenedScreenshot();
        }

        private void CircleCapture_FormClosing(object sender, FormClosingEventArgs e)
        {
         //   Environment.Exit(0);
        }
    }
}
