using System;
using System.Windows.Forms;

public class DesktopExplorer : Form {
    private WebBrowser explorer;

    public DesktopExplorer() {
        this.Text = "Desktop";
        this.Size = new System.Drawing.Size(800, 600);
        this.StartPosition = FormStartPosition.CenterScreen;

        explorer = new WebBrowser();
        explorer.Dock = DockStyle.Fill;
        explorer.Navigate(Environment.GetFolderPath(Environment.SpecialFolder.Desktop));

        this.Controls.Add(explorer);
    }
}

// Run it
public class Program {
    [STAThread]
    public static void Main() {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        
        DesktopExplorer desktopWindow = new DesktopExplorer();
        desktopWindow.Show();
        
        FloatingPanel panel = new FloatingPanel();
        Application.Run(panel);
    }
}
