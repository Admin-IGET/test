import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.util.Stack;

public class MultiNumberCalculator {
    private JFrame frame;
    private JTextField textField;
    private String input = ""; // Holds the current expression

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                MultiNumberCalculator window = new MultiNumberCalculator();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public MultiNumberCalculator() {
        // Set the frame title
        frame = new JFrame("UvikCalc");
        frame.setBounds(100, 100, 400, 550);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        // Create the text field to show the input expression
        textField = new JTextField();
        textField.setBounds(10, 11, 360, 40);
        frame.getContentPane().add(textField);
        textField.setColumns(10);
        textField.setEditable(false);

        // Create the buttons with the new arrangement
        String[] buttonLabels = {
            "1", "2", "3", 
            "4", "5", "6", 
            "7", "8", "9", 
            "0", "+", "-", 
            "*", "/", "=", 
            "C", "<-"
        };

        int x = 10, y = 60;
        for (String label : buttonLabels) {
            JButton button = new JButton(label);
            button.setFont(new Font("Tahoma", Font.PLAIN, 20));
            button.setBounds(x, y, 80, 50);
            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    buttonPressed(label);
                }
            });
            frame.getContentPane().add(button);
            x += 90;
            if (x > 270) {
                x = 10;
                y += 60;
            }
        }

        // Add key listener for number and operator inputs
        frame.addKeyListener(new KeyListener() {
            public void keyPressed(KeyEvent e) {
                char keyChar = e.getKeyChar();
                if (keyChar >= '0' && keyChar <= '9') {
                    buttonPressed(String.valueOf(keyChar));
                } else if (keyChar == '+') {
                    buttonPressed("+");
                } else if (keyChar == '-') {
                    buttonPressed("-");
                } else if (keyChar == '*') {
                    buttonPressed("*");
                } else if (keyChar == '/') {
                    buttonPressed("/");
                } else if (keyChar == '\n') {
                    buttonPressed("=");
                } else if (keyChar == 27) { // ESC key for clear
                    buttonPressed("C");
                } else if (keyChar == 8) { // Backspace key
                    buttonPressed("<-");
                }
            }

            public void keyReleased(KeyEvent e) {}

            public void keyTyped(KeyEvent e) {}
        });

        frame.setFocusable(true); // Allow the frame to be focusable to capture key events
    }

    private void buttonPressed(String label) {
        if (label.equals("=")) {
            evaluateExpression();
        } else if (label.equals("C")) {
            input = "";
            textField.setText(input);
        } else if (label.equals("<-")) {
            if (input.length() > 0) {
                input = input.substring(0, input.length() - 1);
            }
            textField.setText(input);
        } else {
            input += label;  // Append the label to the input expression
            textField.setText(input);
        }
    }

    // Evaluate the input expression using PENDAS (PEMDAS: Parentheses, Exponents, Multiplication/Division, Addition/Subtraction)
    private void evaluateExpression() {
        try {
            // Evaluate the mathematical expression
            double result = evaluateMathExpression(input);
            textField.setText(String.valueOf(result));
            input = String.valueOf(result);  // Update the input to show the result
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Error in expression", "Error", JOptionPane.ERROR_MESSAGE);
            input = "";
            textField.setText("");
        }
    }

    private double evaluateMathExpression(String expression) {
        // Convert the expression to postfix notation and evaluate it
        return evaluatePostfix(infixToPostfix(expression));
    }

    private String infixToPostfix(String infix) {
        StringBuilder postfix = new StringBuilder();
        Stack<Character> operators = new Stack<>();
        StringBuilder numberBuffer = new StringBuilder(); // To capture multi-digit numbers

        for (int i = 0; i < infix.length(); i++) {
            char c = infix.charAt(i);
            if (Character.isDigit(c)) {
                // If the character is a digit, append it to the numberBuffer
                numberBuffer.append(c);
            } else if (c == '.') {
                // If it's a decimal point, allow for floating-point numbers
                numberBuffer.append(c);
            } else {
                // If a complete number has been collected, append it to the postfix expression
                if (numberBuffer.length() > 0) {
                    postfix.append(numberBuffer.toString()).append(" ");
                    numberBuffer.setLength(0);  // Reset the number buffer
                }

                if (c == '(') {
                    // If the character is an opening parenthesis, push it to the operator stack
                    operators.push(c);
                } else if (c == ')') {
                    // If the character is a closing parenthesis, pop from the operator stack until an opening parenthesis is encountered
                    while (operators.peek() != '(') {
                        postfix.append(operators.pop()).append(" ");
                    }
                    operators.pop(); // Remove '(' from stack
                } else if (isOperator(c)) {
                    // If the character is an operator, pop operators from the stack that have greater or equal precedence
                    while (!operators.isEmpty() && precedence(c) <= precedence(operators.peek())) {
                        postfix.append(operators.pop()).append(" ");
                    }
                    operators.push(c); // Push the current operator to the stack
                }
            }
        }

        // If there is a number left in the buffer, append it
        if (numberBuffer.length() > 0) {
            postfix.append(numberBuffer.toString()).append(" ");
        }

        // Append any remaining operators in the stack to the postfix expression
        while (!operators.isEmpty()) {
            postfix.append(operators.pop()).append(" ");
        }

        return postfix.toString().trim();
    }

    private boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/';
    }

    private int precedence(char operator) {
        if (operator == '+' || operator == '-') {
            return 1;
        } else if (operator == '*' || operator == '/') {
            return 2;
        }
        return 0;
    }

    private double evaluatePostfix(String postfix) {
        Stack<BigDecimal> stack = new Stack<>();
        String[] tokens = postfix.split(" ");
        for (String token : tokens) {
            if (isNumber(token)) {
                stack.push(new BigDecimal(token));
            } else if (isOperator(token.charAt(0))) {
                BigDecimal b = stack.pop();
                BigDecimal a = stack.pop();
                switch (token.charAt(0)) {
                    case '+':
                        stack.push(a.add(b));
                        break;
                    case '-':
                        stack.push(a.subtract(b));
                        break;
                    case '*':
                        stack.push(a.multiply(b));
                        break;
                    case '/':
                        if (!b.equals(BigDecimal.ZERO)) {
                            stack.push(a.divide(b));
                        } else {
                            throw new ArithmeticException("Cannot divide by zero");
                        }
                        break;
                }
            }
        }
        return stack.pop().doubleValue(); // Return the result as a double
    }

    private boolean isNumber(String token) {
        try {
            new BigDecimal(token); // Try parsing the token as a BigDecimal (for large numbers)
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
