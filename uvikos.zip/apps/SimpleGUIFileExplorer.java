import javax.swing.*;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.filechooser.FileSystemView;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;

public class SimpleGUIFileExplorer extends JFrame {
    private JTree fileTree;
    private JTable fileTable;
    private DefaultTableModel tableModel;
    private FileSystemView fileSystemView;

    public SimpleGUIFileExplorer() {
        super("Simple File Explorer");

        fileSystemView = FileSystemView.getFileSystemView();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 500);
        setLayout(new BorderLayout());

        // Left Panel: Folder Tree
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("Computer");
        fileTree = new JTree(new DefaultTreeModel(root));
        fileTree.setRootVisible(false);
        loadFileTree(root, new File(System.getProperty("user.home"))); // Start at user home directory

        JScrollPane treeScroll = new JScrollPane(fileTree);
        treeScroll.setPreferredSize(new Dimension(250, 0));

        // Right Panel: File Table (like Windows Explorer)
        String[] columnNames = {"Name", "Size", "Type"};
        tableModel = new DefaultTableModel(columnNames, 0);
        fileTable = new JTable(tableModel);
        fileTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane tableScroll = new JScrollPane(fileTable);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, treeScroll, tableScroll);
        splitPane.setDividerLocation(250);
        add(splitPane, BorderLayout.CENTER);

        // Handle folder selection in JTree
        fileTree.addTreeSelectionListener((TreeSelectionEvent e) -> {
            DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) fileTree.getLastSelectedPathComponent();
            if (selectedNode != null && selectedNode.getUserObject() instanceof File) {
                File selectedFolder = (File) selectedNode.getUserObject();
                loadFileTable(selectedFolder);
            }
        });

        // Handle double-click to open files
        fileTable.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    int selectedRow = fileTable.getSelectedRow();
                    if (selectedRow != -1) {
                        File selectedFile = (File) tableModel.getValueAt(selectedRow, 0);
                        openFile(selectedFile);
                    }
                }
            }
        });

        setVisible(true);
    }

    private void loadFileTree(DefaultMutableTreeNode node, File folder) {
        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(file);
                    node.add(childNode);
                }
            }
        }
    }

    private void loadFileTable(File folder) {
        tableModel.setRowCount(0); // Clear previous data
        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                String type = file.isDirectory() ? "Folder" : "File";
                String size = file.isFile() ? file.length() + " bytes" : "";
                tableModel.addRow(new Object[]{file, size, type});
            }
        }
    }

    private void openFile(File file) {
        try {
            Desktop.getDesktop().open(file);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Unable to open file: " + file.getAbsolutePath(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(SimpleGUIFileExplorer::new);
    }
}
