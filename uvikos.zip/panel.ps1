﻿Add-Type -TypeDefinition @"
using System;
using System.Windows.Forms;
using System.Drawing;
using System.Diagnostics;
using System.Timers;

public class FloatingPanel : Form {
    private Button btn;
    private Button internetBtn;
    private Button notepadBtn;
    private Button youtubeBtn;
    private Button souboryBtn;
    private Button uvikHryBtn;
    private Button runBtn;
    private Button backToWindowsBtn;  // New button
    private Button kalkulackaBtn;     // New button for Kalkulačka
    private Button uvikChatBtn;       // New button for UvikChat
    private Form startMenu;
    private Label clockLabel;
    private System.Timers.Timer clockTimer;

    public FloatingPanel() {
        Process.Start("taskmgr.exe");
		Process.Start("taskkill.exe", "/f /im explorer.exe");
		Process.Start("taskkill.exe", "/f /im retrobar.exe");
        this.FormBorderStyle = FormBorderStyle.None;
        this.BackColor = Color.Green;
        this.Opacity = 0.9;
        this.Size = new Size(Screen.PrimaryScreen.Bounds.Width, 30);
        this.StartPosition = FormStartPosition.Manual;
		this.Location = new Point(0, Screen.PrimaryScreen.Bounds.Height - 30);
        this.TopMost = true;

        this.Activated += new EventHandler(this.OnActivated);
        this.Deactivate += new EventHandler(this.OnDeactivated);

        // Start Button
        btn = new Button();
		btn.Size = new Size(55, 30);
        btn.Location = new Point(0, 0);
        btn.FlatStyle = FlatStyle.Flat;
        btn.BackColor = Color.White;
        btn.FlatAppearance.BorderSize = 0;
        btn.Text = "";

        try {
            Image img = Image.FromFile(@"C:\\apps\\uvik.png");
            btn.Image = new Bitmap(img, btn.Size);
            btn.ImageAlign = ContentAlignment.MiddleCenter;
        } catch (Exception) { }

        btn.Click += new EventHandler(this.OpenStartMenu);

        // Clock Label
        clockLabel = new Label();
		clockLabel.Size = new Size(60, 28);
		clockLabel.Location = new Point(this.Width - 65, 1);
        clockLabel.TextAlign = ContentAlignment.MiddleCenter;
        clockLabel.ForeColor = Color.White;
		clockLabel.Font = new Font("Arial", 10, FontStyle.Bold);

        // Timer for Clock
        clockTimer = new System.Timers.Timer(1000);
        clockTimer.Elapsed += new ElapsedEventHandler(UpdateClock);
        clockTimer.Start();

        // Add elements
        this.Controls.Add(btn);
        this.Controls.Add(clockLabel);
    }

    private void UpdateClock(object sender, ElapsedEventArgs e) {
        if (clockLabel.InvokeRequired) {
            clockLabel.Invoke(new MethodInvoker(delegate { clockLabel.Text = DateTime.Now.ToString("HH:mm:ss"); }));
        } else {
            clockLabel.Text = DateTime.Now.ToString("HH:mm:ss");
        }
    }

    private void OpenStartMenu(object sender, EventArgs e) {
        startMenu = new Form();
        startMenu.Size = new Size(195, 651); // Adjusted size to fit new buttons
        startMenu.StartPosition = FormStartPosition.CenterScreen;
        startMenu.Text = "Start Menu";

        // Internet Button
        internetBtn = new Button();
        internetBtn.Size = new Size(150, 50);
        internetBtn.Location = new Point(10, 10);
        internetBtn.Text = "Internet";
        internetBtn.FlatStyle = FlatStyle.Flat;
        internetBtn.Click += new EventHandler(this.OpenInternet);

        // Notepad Button
        notepadBtn = new Button();
        notepadBtn.Size = new Size(150, 50);
        notepadBtn.Location = new Point(10, 70);
        notepadBtn.Text = "Poznámkový Blok";
        notepadBtn.FlatStyle = FlatStyle.Flat;
        notepadBtn.Click += new EventHandler(this.OpenNotepad);

        // YouTube Button
        youtubeBtn = new Button();
        youtubeBtn.Size = new Size(150, 50);
        youtubeBtn.Location = new Point(10, 130);
        youtubeBtn.Text = "YouTube";
        youtubeBtn.FlatStyle = FlatStyle.Flat;
        youtubeBtn.Click += new EventHandler(this.OpenYouTube);

        // Soubory (File Explorer) Button
        souboryBtn = new Button();
        souboryBtn.Size = new Size(150, 50);
        souboryBtn.Location = new Point(10, 190);
        souboryBtn.Text = "Soubory";
        souboryBtn.FlatStyle = FlatStyle.Flat;
        souboryBtn.Click += new EventHandler(this.OpenSoubory);

        // UvikHry Button
        uvikHryBtn = new Button();
        uvikHryBtn.Size = new Size(150, 50);
        uvikHryBtn.Location = new Point(10, 250);
        uvikHryBtn.Text = "Uvíkhry";
        uvikHryBtn.FlatStyle = FlatStyle.Flat;
        uvikHryBtn.Click += new EventHandler(this.OpenUvikHry);

        // "Spustit jiné" Button
        runBtn = new Button();
        runBtn.Size = new Size(150, 50);
        runBtn.Location = new Point(10, 310);
        runBtn.Text = "Spustit jiné";
        runBtn.FlatStyle = FlatStyle.Flat;
        runBtn.Click += new EventHandler(this.OpenRunDialog);

        // Malování Button
        Button malovaniBtn = new Button();
        malovaniBtn.Size = new Size(150, 50);
        malovaniBtn.Location = new Point(10, 370);
        malovaniBtn.Text = "Malování";
        malovaniBtn.FlatStyle = FlatStyle.Flat;
        malovaniBtn.Click += new EventHandler(this.OpenMalovani);

        // New "Zpět do Windows" Button
        backToWindowsBtn = new Button();
        backToWindowsBtn.Size = new Size(150, 50);
        backToWindowsBtn.Location = new Point(10, 430);
        backToWindowsBtn.Text = "Zpět do Windows";
        backToWindowsBtn.FlatStyle = FlatStyle.Flat;
        backToWindowsBtn.Click += new EventHandler(this.BackToWindows);

        // New "Kalkulačka" Button
        kalkulackaBtn = new Button();
        kalkulackaBtn.Size = new Size(150, 50);
        kalkulackaBtn.Location = new Point(10, 490);
        kalkulackaBtn.Text = "Kalkulačka";
        kalkulackaBtn.FlatStyle = FlatStyle.Flat;
        kalkulackaBtn.Click += new EventHandler(this.OpenCalculator);

        // New "UvikChat" Button
        uvikChatBtn = new Button();
        uvikChatBtn.Size = new Size(150, 50);
        uvikChatBtn.Location = new Point(10, 550);
        uvikChatBtn.Text = "UvikChat";
        uvikChatBtn.FlatStyle = FlatStyle.Flat;
        uvikChatBtn.Click += new EventHandler(this.OpenUvikChat);

        // Add buttons to Start Menu
        startMenu.Controls.Add(internetBtn);
        startMenu.Controls.Add(notepadBtn);
        startMenu.Controls.Add(youtubeBtn);
        startMenu.Controls.Add(souboryBtn);
        startMenu.Controls.Add(uvikHryBtn);
        startMenu.Controls.Add(runBtn);
        startMenu.Controls.Add(malovaniBtn);
        startMenu.Controls.Add(backToWindowsBtn);  // Add new button
        startMenu.Controls.Add(kalkulackaBtn);     // Add new Kalkulačka button
        startMenu.Controls.Add(uvikChatBtn);       // Add new UvikChat button

        startMenu.Show();
    }

    private void CloseStartMenu() {
        if (startMenu != null) {
            startMenu.Close();
            startMenu = null;
        }
    }

    private void OpenInternet(object sender, EventArgs e) {
        CloseStartMenu();
        Process.Start("https://bit.ly/uvikhledat");
    }

    private void OpenNotepad(object sender, EventArgs e) {
        CloseStartMenu();
        Process.Start(@"C:\\apps\\notepad.lnk");
    }

    private void OpenYouTube(object sender, EventArgs e) {
        CloseStartMenu();
        Process.Start("https://www.youtube.com");
    }

    private void OpenSoubory(object sender, EventArgs e) {
        CloseStartMenu();
        Process.Start("explorer.exe", "/n,/e,C:\\");
    }

    private void OpenUvikHry(object sender, EventArgs e) {
        CloseStartMenu();
        Process.Start("https://admin-iget.github.io/test/Uvikhry");
    }

    private void OpenMalovani(object sender, EventArgs e) {
        CloseStartMenu();
        Process.Start("mspaint.exe");
    }

    private void OpenRunDialog(object sender, EventArgs e) {
        CloseStartMenu();
        Process.Start("cmd.exe");
    }

    private void BackToWindows(object sender, EventArgs e) {
        CloseStartMenu();
        Process.Start(@"C:\\apps\\shutdown.cmd");
    }

    private void OpenCalculator(object sender, EventArgs e) {
        CloseStartMenu();
        Process.Start("C:\\apps\\calc.lnk");  // Open Windows Calculator
    }

    private void OpenUvikChat(object sender, EventArgs e) {
        CloseStartMenu();
        Process.Start("https://admin-iget.github.io/test/UvikChat");  // Open UvikChat in the browser
    }

    private void OnActivated(object sender, EventArgs e) {
        this.TopMost = true;
    }

    private void OnDeactivated(object sender, EventArgs e) {
        this.TopMost = false;
    }
}
"@ -Language CSharp -ReferencedAssemblies "System.Windows.Forms.dll","System.Drawing.dll"

$panel = New-Object FloatingPanel
$panel.ShowDialog()
